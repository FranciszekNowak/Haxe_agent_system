// Haxe Sorino HX705/HX707 — PDP scripts
